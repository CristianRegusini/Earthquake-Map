import PocketBase from 'pocketbase';

const pb = new PocketBase('http://127.0.0.1:8090');

// Mantieni la sessione
pb.authStore.loadFromCookie(document.cookie);
pb.authStore.onChange(() => {
    document.cookie = pb.authStore.exportToCookie();
});

// --- ELEMENTI DOM ---
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const showRegister = document.getElementById("showRegister");
const showLogin = document.getElementById("showLogin");
const loginContainer = document.getElementById("loginContainer");
const appContainer = document.getElementById("app");
const logoutBtn = document.getElementById("logoutBtn");

// --- MOSTRA APP SE LOGGATO ---
function showApp() {
    loginContainer.style.display = "none";
    appContainer.style.display = "block";

    try {
        initMapAndFetch();
    } catch(err) {
        console.error("Errore nell'inizializzazione della mappa:", err);
        alert("Impossibile caricare la mappa. Controlla la console.");
    }
}

if(pb.authStore.isValid){
    showApp();
}

// --- SWITCH LOGIN / REGISTRAZIONE ---
showRegister.addEventListener("click", e => {
    e.preventDefault();
    loginForm.style.display = "none";
    registerForm.style.display = "block";
});

showLogin.addEventListener("click", e => {
    e.preventDefault();
    loginForm.style.display = "block";
    registerForm.style.display = "none";
});

// --- FORM REGISTRAZIONE ---
registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("regEmail").value;
    const password = document.getElementById("regPassword").value;
    const passwordConfirm = document.getElementById("regPasswordConfirm").value;

    try{
        await pb.collection("users").create({
            email,
            password,
            passwordConfirm
        });
        alert("Registrazione completata! Ora effettua il login.");
        registerForm.style.display = "none";
        loginForm.style.display = "block";
    } catch(err){
        alert("Errore: "+err.message);
    }
});

// --- FORM LOGIN ---
loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    try{
        await pb.collection("users").authWithPassword(email,password);
        showApp();
    } catch(err){
        alert("Credenziali errate!");
    }
});

// --- LOGOUT ---
logoutBtn.addEventListener("click", () => {
    pb.authStore.clear();
    location.reload();
});

// --- FUNZIONI TERREMOTI / MAPPA ---
function calcolaRaggioTerremoto(mag, depth) {
    if (typeof mag !== 'number' || typeof depth !== 'number' || mag <= 0 || depth < 0) {
        console.error("Dati di magnitudo (M) o profondità (H) non validi.");
        return null;
    }
    const epicentralRadiusKm = Math.pow(10, (0.4 * mag) - 1.2);
    const radiusKm = epicentralRadiusKm + depth;
    return radiusKm * 1000;
}

function getColor(mag) {
    return mag >= 6 ? "#ff0000" :
           mag >= 5 ? "#ff4500" :
           mag >= 4 ? "#ff8c00" :
           mag >= 3 ? "#ffa500" :
                      "#ffff00";
}

// --- NUOVA FUNZIONE RAGGIO BASED ON COLOR/MAGNITUDO ---
function getRadiusByMagAndColor(mag) {
    let base = 5000;
    let size = base * mag;

    if (mag >= 6) return size * 2.5;
    if (mag >= 5) return size * 1.8;
    if (mag >= 4) return size * 1.3;
    if (mag >= 3) return size;
    return size * 0.7;
}

function initMapAndFetch(){
    // --- MAPPA ---
    const map = L.map('map').setView([45.4297, 10.1861], 2);

    // --- TILE SATELLITARE (immagini)
    const satelliteTile = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri &copy; OSM',
        maxZoom: 19
    }).addTo(map);

    // --- TILE ETICHETTE (città, nomi, strade)
    const labelsTile = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Labels &copy; Esri',
        maxZoom: 19,
        pane: 'overlayPane'
    }).addTo(map);

    // --- TILE GEOGRAFICO (chiaro)
    const geographicTile = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19
    });

    // --- LAYER SWITCHER posizionato bottom-left ---
    L.control.layers({
        "Satellite": L.layerGroup([satelliteTile, labelsTile]),
        "Geografico": geographicTile
    }, null, {position: 'bottomleft'}).addTo(map);

    // --- FETCH TERREMOTI ---
    fetch("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson")
    .then(r => r.json())
    .then(body => {
        const terremoti = body.features;
        console.log(`Trovati ${terremoti.length} terremoti nell'ultima ora.`);

        const terremotiLayer = L.layerGroup().addTo(map);

        terremoti.forEach(terremoto => {
            const [lng, lat, depth] = terremoto.geometry.coordinates;
            const mag = terremoto.properties.mag;
            const place = terremoto.properties.place;
            const time = new Date(terremoto.properties.time).toLocaleString();

            const raggioStimatoMetri = calcolaRaggioTerremoto(mag, depth);

            // --- SALVATAGGIO POCKETBASE ---
            const data = {
                usgs_id: terremoto.id,
                magnitudo: mag,
                luogo: place,
                latitudine: lat,
                longitudine: lng,
                profondita: depth,
                DateTime: new Date(terremoto.properties.time).toISOString(),
                raggio_stimato_metri: raggioStimatoMetri
            };

            pb.collection('terremoti').create(data).catch(error=>{
                console.error(`Errore nel salvataggio su PocketBase per ${place}:`, error);
            });

            // --- CERCHI PULSANTI CON RAGGIO VARIABILE ---
            if (raggioStimatoMetri !== null) {
                const circle = L.circle([lat, lng], {
                    color: getColor(mag),
                    fillColor: getColor(mag),
                    fillOpacity: 0.7,
                    radius: getRadiusByMagAndColor(mag),
                    weight: 1
                }).addTo(terremotiLayer);

                circle.bindPopup(`
                    <div style="font-family:Arial;font-size:14px;">
                        <b>${place}</b><br>
                        <span style="color:${getColor(mag)};">●</span> Magnitudo: ${mag}<br>
                        Profondità: ${depth} km<br>
                        Ora: ${time}<br>
                        Raggio stimato: ${(raggioStimatoMetri/1000).toFixed(1)} km
                    </div>
                `);

                // Effetto pulsante
                let growing = true;
                let radius = getRadiusByMagAndColor(mag);
                setInterval(() => {
                    if (growing) radius += 500;
                    else radius -= 500;
                    if (radius > getRadiusByMagAndColor(mag)*1.5) growing = false;
                    if (radius < getRadiusByMagAndColor(mag)) growing = true;
                    circle.setRadius(radius);
                }, 200);
            }
        });

        // --- LEGENDA MODERNA ---
        const legend = L.control({position: 'bottomright'});
        legend.onAdd = function () {
            const div = L.DomUtil.create('div', 'info legend');
            const grades = [0,3,4,5,6];
            div.innerHTML = '<b>Magnitudo</b><br>';
            grades.forEach((g,i) => {
                div.innerHTML +=
                    `<i style="background:${getColor(g+1)}; border-radius:50%; width:15px; height:15px; display:inline-block;"></i> ` +
                    g + (grades[i+1] ? '&ndash;' + grades[i+1] + '<br>' : '+');
            });
            return div;
        };
        legend.addTo(map);

    })
    .catch(error=>{
        console.error("Errore nel recupero dei dati sismici:", error);
    });
}
