import './style.css'

import PocketBase from 'pocketbase';

const pb = new PocketBase('http://127.0.0.1:8090');

function calcolaRaggioTerremoto(mag, depth) {

    if (typeof mag !== 'number' || typeof depth !== 'number' || mag <= 0 || depth < 0) {

        console.error("Dati di magnitudo (M) o profondità (H) non validi.");

        return null;

    }

    const epicentralRadiusKm = Math.pow(10, (0.4 * mag) - 1.2);

    const radiusKm = epicentralRadiusKm + depth;

    const radiusMeters = radiusKm * 1000;

    return radiusMeters;

}




const map = L.map('map').setView([45.4297, 10.1861], 2);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {

    maxZoom: 19,

    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'

}).addTo(map);



// 2. Aggiungi la logica di salvataggio all'interno del .then() di fetch

fetch("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson")

.then(r => r.json())

.then(body => {

    const terremoti = body.features;

    console.log(`Trovati ${terremoti.length} terremoti nell'ultima ora.`);

   

    for(const terremoto of terremoti){

        const lng = terremoto.geometry.coordinates[0];

        const lat = terremoto.geometry.coordinates[1];

        const depth = terremoto.geometry.coordinates[2]; // Profondità in km

        const mag = terremoto.properties.mag;

        const place = terremoto.properties.place;

        const time = terremoto.properties.time; // Aggiungi il timestamp per un dato utile

       

        const raggioStimatoMetri = calcolaRaggioTerremoto(mag, depth);



        // --- INIZIO: LOGICA POCKETBASE ---

        // Prepara i dati per l'inserimento

        const data = {

            "usgs_id": terremoto.id,

            "magnitudo": mag,

            "luogo": place,

            "latitudine": lat,

            "longitudine": lng,

            "profondita": depth,

            "DateTime": new Date(time).toISOString(), // Converti il timestamp (ms) in formato ISO

            "raggio_stimato_metri": raggioStimatoMetri

        };



        // Inserisci il record nella collezione 'terremoti'

        pb.collection('terremoti').create(data)

            .then(record => {

                // Console.log per conferma (opzionale)

                // console.log("Terremoto salvato su PocketBase:", record);

            })

            .catch(error => {

                // Gestione degli errori di salvataggio (es. validazione)

                console.error(`Errore nel salvataggio su PocketBase per ${place}:`, error);

            });

        // --- FINE: LOGICA POCKETBASE ---

        if (raggioStimatoMetri !== null) {

            const circle = L.circle([lat, lng], {

                color: '#f00',

                fillColor: '#f03',

                fillOpacity: 0.9,

                radius: raggioStimatoMetri

            }).addTo(map);

           

            circle.bindPopup(`Magnitudo: ${mag}<br>Luogo: ${place}<br>Raggio Effetti (stimato): ${(raggioStimatoMetri / 1000).toFixed(1)} km`);

           

            let opacity = circle.options.fillOpacity;

            const intervalID = setInterval(() => {

                opacity -= 0.1;

                if (opacity <= 0) {

                    map.removeLayer(circle);

                    clearInterval(intervalID);

                } else {

                    circle.setStyle({ fillOpacity: opacity, opacity: opacity });

                }

            }, 3000);
        }

    }

})

.catch(error => {

    console.error("Errore nel recupero dei dati sismici:", error);

});