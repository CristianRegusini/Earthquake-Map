let earthquakeList = [];

function fetchEarthquakes() {
    fetch('URL_TERREMOTI') // Sostituisci con l'URL reale
        .then(response => response.json())
        .then(data => {
            data.features.forEach(eq => {
                if (!earthquakeList.some(e => e.id === eq.id)) {
                    earthquakeList.push(eq);
                }
            });
            updateEarthquakeListUI();
        });
}

function updateEarthquakeListUI() {
    // Aggiorna la visualizzazione della lista dei terremoti
    // ...
}

setInterval(fetchEarthquakes, 10000);
fetchEarthquakes();