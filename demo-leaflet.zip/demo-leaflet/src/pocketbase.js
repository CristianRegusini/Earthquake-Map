// src/superuser.js
import PocketBase from "pocketbase"

const db = new PocketBase('http://127.0.0.1:8090');

// disable autocancellation so that we can handle async requests from multiple users
db.autoCancellation(false);

// option 2: OR authenticate as superuser via long-lived "API key"
// (see https://pocketbase.io/docs/authentication/#api-keys)
db.authStore.save('YOUR_GENERATED_SUPERUSER_TOKEN')

export default db;