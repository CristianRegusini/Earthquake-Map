// main.js

import './style.css'
import PocketBase from "pocketbase" 

// =================================================================
// 0. INIZIALIZZAZIONE GLOBALE E POCKETBASE
// =================================================================

const db = new PocketBase('http://127.0.0.1:8090'); 

// 1. Inizializzazione della Mappa
const map = L.map('map').setView([45.4297, 10.1861], 3);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    minZoom: 2,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

// 2. Definizione degli Stati Globali
const earthquakeLayer = L.layerGroup().addTo(map);
const markerMap = {}; 
const knownEarthquakes = new Set(); 
let isGestioneRunning = false; // Lock

// Riferimenti agli elementi di controllo
const minMagInput = document.getElementById('minMagnitude');
const applyFilterButton = document.getElementById('applyFilter');
let minMagnitude = parseFloat(minMagInput?.value) || 0.0; 

// Impostazioni
const OPACITY_NEW = 1.0;
const OPACITY_MIN = 0.05;
const DATA_REFRESH_RATE = 10000; 
const FADE_REFRESH_RATE = 1000;
const BATCH_SIZE = 5; // Dimensione dei lotti per il salvataggio

// =================================================================
// FUNZIONI DI UTILITÀ (Invariate)
// =================================================================

function getColorByMagnitude(mag) {
    if (mag >= 5.0) return 'darkred';
    if (mag >= 4.0) return 'red';
    if (mag >= 3.0) return 'orange';
    if (mag >= 2.0) return 'yellow';
    return 'green'; 
}

function buildPopupContent(data) {
    const time = new Date(data.time).toLocaleString('it-IT');
    const source = data.source === 'pb' ? 'Archivio PocketBase' : 'USGS (Live)';
    
    return `
        <div style="max-width: 250px;">
            <h3 style="margin-bottom: 5px; color: ${getColorByMagnitude(data.mag)};">Terremoto M${data.mag.toFixed(1)}</h3>
            <p><strong>Luogo:</strong> ${data.place}</p>
            <p><strong>Ora (IT):</strong> ${time}</p>
            <p><strong>Profondità:</strong> ${data.depth.toFixed(1)} km</p>
            <p style="margin-top: 5px; font-size: 0.8em;">Fonte: ${source}</p>
        </div>
    `;
}

function drawEarthquakeMarker(data, isNew = false) {
    if (knownEarthquakes.has(data.id)) return;
    if (data.mag < minMagnitude) return;
    
    knownEarthquakes.add(data.id);
    
    const radius = 3000 + Math.pow(3.5, data.mag); 
    const clampedMag = Math.max(2.0, Math.min(6.0, data.mag));
    const durationSeconds = 20 * Math.pow(clampedMag, 2);
    
    const fillOpacity = isNew ? OPACITY_NEW : OPACITY_MIN + 0.05; 
    const fadeStep = isNew ? Math.max(0.001, OPACITY_NEW / durationSeconds) : 0; 
    
    const circle = L.circle([data.lat, data.long], {
        color: getColorByMagnitude(data.mag),
        fillColor: getColorByMagnitude(data.mag),
        fillOpacity: fillOpacity, 
        radius: radius
    });
    
    circle.bindPopup(buildPopupContent(data));
    circle.addTo(earthquakeLayer);
    circle.fadeStep = fadeStep; 
    markerMap[data.id] = circle; 
}


// =================================================================
// POCKETBASE: SALVATAGGIO E CARICAMENTO STORICO (Invariati)
// =================================================================

async function saveEarthquakeToPocketBase(data) {
    const recordData = {
        usgs_id: data.id,
        magnitudo: data.mag,
        luogo: data.place,
        latitudine: data.lat,
        longitudine: data.long,
        profondita: data.depth,
        tempo: new Date(data.time).toISOString(), 
    };

    try {
        await db.collection('terremoti').create(
            recordData,
            { autoCancellation: false } 
        );
    } catch (e) {
        if (e.status === 400 && e.message.includes("usgs_id")) {
             return; // Errore atteso per duplicati, silenzia
        }
        // Registra solo errori critici, non l'errore di auto-cancellazione (che ora è gestito)
        if (e.status !== 0) { 
            console.error(`[PocketBase] Errore critico durante il salvataggio di ${data.id}:`, e);
        }
    }
}

async function loadHistoricalEarthquakes() {
    console.log("[PocketBase] Caricamento dati storici...");
    try {
        const records = await db.collection('terremoti').getFullList({
            sort: '-tempo',
            filter: `magnitudo >= ${minMagnitude}`,
            autoCancellation: false 
        });

        records.forEach(record => {
            const data = {
                id: record.id,
                place: record.luogo,
                mag: record.magnitudo,
                time: new Date(record.tempo).getTime(),
                lat: record.latitudine,
                long: record.longitudine,
                depth: record.profondita,
                source: 'pb'
            };
            drawEarthquakeMarker(data, false); 
        });

        console.log(`[PocketBase] Caricati ${records.length} terremoti storici.`);
    } catch (error) {
        console.error("[PocketBase] Errore nel caricamento dei dati storici:", error);
    }
}


// =================================================================
// FUNZIONE 1: GESTIONE DATI LIVE (MODIFICATA CON BATCHING)
// =================================================================
async function gestioneTerr() {
    
    if (isGestioneRunning) {
        return; 
    }
    isGestioneRunning = true; 

    try {
        const r = await fetch("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson");
        const body = await r.json();
        
        const filteredEarthquakes = body.features.filter(terremoto => {
            const mag = terremoto.properties.mag;
            return mag >= minMagnitude; 
        });

        const savePromises = []; 
        
        for (const terremoto of filteredEarthquakes) {
            const id = terremoto.id;
            
            if (!knownEarthquakes.has(id)) {
                
                const lat = terremoto.geometry.coordinates[1];
                const long = terremoto.geometry.coordinates[0];
                const depth = terremoto.geometry.coordinates[2]; 
                const mag = terremoto.properties.mag;
                const place = terremoto.properties.place;
                const time = terremoto.properties.time; 
                
                const earthquakeData = {
                    id: id, place: place, mag: mag, time: time,
                    lat: lat, long: long, depth: depth, source: 'usgs'
                };

                // NON chiamiamo await qui, prepariamo solo la promise
                savePromises.push(() => saveEarthquakeToPocketBase(earthquakeData));

                drawEarthquakeMarker(earthquakeData, true);
            }
        }
        
        // ========================================================
        // === NUOVA LOGICA DI BATCHING (Sostituisce Promise.all) ===
        // ========================================================
        if (savePromises.length > 0) {
            // console.log(`[Gestione] Trovati ${savePromises.length} nuovi items. Avvio salvataggio in batch...`);
            
            for (let i = 0; i < savePromises.length; i += BATCH_SIZE) {
                // Estrai un "lotto" di promise dall'array
                const batchPromises = savePromises.slice(i, i + BATCH_SIZE).map(func => func());
                
                // Attendi solo il completamento di questo lotto
                await Promise.all(batchPromises); 
                
                // Pausa opzionale se PocketBase è ancora sovraccarico (ma di solito non serve)
                // await new Promise(resolve => setTimeout(resolve, 50)); 
            }
            // console.log(`[Gestione] Salvataggio in batch completato.`);
        }
        // ========================================================

    } catch (error) {
        console.error("[USGS] Errore durante il recupero dei dati sismici:", error);
    } finally {
        isGestioneRunning = false;
    }
}


// =================================================================
// GESTIONE FILTRO (Invariato)
// =================================================================
async function handleFilterChange() {
    minMagnitude = parseFloat(minMagInput.value) || 0.0; 

    earthquakeLayer.clearLayers(); 
    Object.keys(markerMap).forEach(id => delete markerMap[id]);
    knownEarthquakes.clear();
    
    await loadHistoricalEarthquakes(); 
    await gestioneTerr(); 
}

if (applyFilterButton && minMagInput) {
    applyFilterButton.addEventListener('click', handleFilterChange);
    minMagInput.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') handleFilterChange();
    });
}


// =================================================================
// FUNZIONE 2: AGGIORNAMENTO OPACITÀ (Invariata)
// =================================================================
function aggiornaOpacita() {
    Object.keys(markerMap).forEach(id => {
        const circle = markerMap[id];
        const step = circle.fadeStep; 

        if (step === 0) return; 

        const currentOpacity = circle.options.fillOpacity;
        const newOpacity = Math.max(0, currentOpacity - step);

        if (newOpacity > OPACITY_MIN) {
            circle.setStyle({ fillOpacity: newOpacity });
        } else {
            earthquakeLayer.removeLayer(circle);
            delete markerMap[id];
            knownEarthquakes.delete(id);
        }
    });
}


// =================================================================
// AVVIO (Invariato)
// =================================================================

(async () => {
    await loadHistoricalEarthquakes(); 
    await gestioneTerr();
    
    setInterval(gestioneTerr, DATA_REFRESH_RATE);
    setInterval(aggiornaOpacita, FADE_REFRESH_RATE);
})();