import PocketBase from 'pocketbase';

const POCKETBASE_URL = 'http://127.0.0.1:8090';
export const pb = new PocketBase(POCKETBASE_URL);


export async function loginUser(email, password) {
    try {
        const authData = await pb.collection('users').authWithPassword(email, password);
        console.log('Login riuscito. ID Utente:', authData.record.id);
        return authData;
    } catch (error) {
        console.error('Errore durante il login:', error);
        throw new Error('Credenziali non valide o errore di connessione.');
    }
}

export function logoutUser() {
    pb.authStore.clear();
    console.log('Logout eseguito.');
}


export function isAuthenticated() {
    return pb.authStore.isValid;
}


export async function createTask(title) {
    if (!isAuthenticated()) {
        throw new Error('Devi essere autenticato per creare un task.');
    }
    
    const currentUserId = pb.authStore.model.id;

    try {
        const newRecord = await pb.collection('tasks').create({
            title: title,
            user: currentUserId
        });
        console.log('Task creato con successo.');
        return newRecord;
    } catch (error) {
        console.error('Errore durante la creazione del task:', error);
        throw error;
    }
}

export async function saveEarthquake(data) {
    try {
        const newRecord = await pb.collection('earthquakes').create(data);
        console.log(`Dato sismico salvato con successo: ${newRecord.event_id}`);
        return newRecord;
    } catch (error) {
        console.error('Errore durante il salvataggio del dato sismico:', error);
        throw error;
    }
}