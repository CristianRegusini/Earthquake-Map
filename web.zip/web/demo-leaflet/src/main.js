import './style.css'
import {loginUser,logoutUser,isAuthenticated,createTask,saveEarthquake} from './PocketBase.js';

const knownTerremoti = new Set();

function calcolaRaggioTerremoto(mag, depth) {
    if (typeof mag !== 'number' || typeof depth !== 'number' || mag <= 0 || depth < 0) {
        console.error("Dati di magnitudo (M) o profondità (H) non validi.");
        return null;
    }
    const epicentralRadiusKm = Math.pow(10, (0.4 * mag) - 1.2);
    const radiusKm = epicentralRadiusKm + depth;
    const radiusMeters = radiusKm * 1000;
    return radiusMeters;
}

const map = L.map('map').setView([45.4297, 10.1861], 2);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

fetch("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson")
.then(r => r.json())
.then(body => {
    const terremoti = body.features;
    console.log(`Trovati ${terremoti.length} terremoti di Magnitudo > 4.5 nell'ultima settimana.`);
    
    for(const terremoto of terremoti){
        const id = terremoto.id
        if(!knownTerremoti.has(id)){
            knownTerremoti.add(id)
            const lng = terremoto.geometry.coordinates[0];
            const lat = terremoto.geometry.coordinates[1];
            const depth = terremoto.geometry.coordinates[2]; 
            const mag = terremoto.properties.mag;
            const place = terremoto.properties.place;
            
            const formattedTime = new Date(terremoto.properties.time).toLocaleString(); 
            
            const raggioStimatoMetri = calcolaRaggioTerremoto(mag, depth);
            
            if (raggioStimatoMetri !== null) {
                const earthquakeData = {
                    event_id: id,
                    latitude: lat,
                    longitude: lng,
                    magnitude: mag,
                    depth: depth,
                    place: place,
                    event_time: new Date(terremoto.properties.time).toISOString(), 
                    calculated_radius: raggioStimatoMetri,
                };
                
                saveEarthquake(earthquakeData)
                    .catch(e => console.error(`Non sono riuscito a salvare il terremoto ${id}: ${e.message}`));

                const circle = L.circle([lat, lng], {
                    color: '#f00',
                    fillColor: '#f03',
                    fillOpacity: 0.9,
                    radius: raggioStimatoMetri 
                }).addTo(map);
                
                circle.bindPopup(
                    `Magnitudo: ${mag}<br>` +
                    `Luogo: ${place}<br>` +
                    `Data/Ora: ${formattedTime}<br>` +
                    `Raggio Effetti (stimato): ${(raggioStimatoMetri / 1000).toFixed(1)} km`
                );
                
                
                
                let opacity = circle.options.fillOpacity;
                const intervalID = setInterval(() => {
                    opacity -= 0.1; 
                    if (opacity <= 0) {
                        map.removeLayer(circle);
                        clearInterval(intervalID);
                    } else {
                        circle.setStyle({ fillOpacity: opacity, opacity: opacity }); 
                    }
                }, 2000);
            }
        }
    }
})
.catch(error => {
    console.error("Errore nel recupero dei dati sismici:", error);
});